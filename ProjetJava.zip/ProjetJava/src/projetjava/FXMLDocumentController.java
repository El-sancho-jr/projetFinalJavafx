/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjava;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javax.swing.JOptionPane;
import static projetjava.MysqlConnect.ConnectDb;

/**
 *
 * @author ester maria
 */
public class FXMLDocumentController implements Initializable {
    
     @FXML
    private TableView<Etudiant> TabEtudiant;

    @FXML
    private TableColumn<Etudiant, Integer> MatriculeCol;

    @FXML
    private TableColumn<Etudiant, String> NomCol;

    @FXML
    private TableColumn<Etudiant, String> PrenomCol;

    @FXML
    private TableColumn<Etudiant, String> GroupeCol;

    @FXML
    private TableColumn<Etudiant, String> NaissanceCol;

    @FXML
    private TableColumn<Etudiant, String> TelephoneCol;

    @FXML
    private TableColumn<Etudiant, String> AdresseCol;

    @FXML
    private TableColumn<Etudiant, String> EmailCol;

    @FXML
    private TableColumn<Etudiant, String>  FillierCol;
    
     @FXML
    private TextField txtMatricule;

    @FXML
    private TextField txtNom;

    @FXML
    private TextField txtPrenom;

    @FXML
    private TextField txtGroupe;

    @FXML
    private TextField txtNaissance;

    @FXML
    private TextField txtTelephone;

    @FXML
    private TextField txtAdresse;

    @FXML
    private TextField txtEmail;

    @FXML
    private TextField txtFillier;
    
    @FXML
    private TableView<Professeur> TabProfesseur;

    @FXML
    private TableColumn<Professeur, Integer> MatriculeColProf;

    @FXML
    private TableColumn<Professeur, String> NomColProf;

    @FXML
    private TableColumn<Professeur, String> PrenomColProf;

    @FXML
    private TableColumn<Professeur, String> GroupeColProf;

    @FXML
    private TableColumn<Professeur, String> NaissanceColProf;

    @FXML
    private TableColumn<Professeur, String> TelephoneColProf;

    @FXML
    private TableColumn<Professeur, String> AdresseColProf;

    @FXML
    private TableColumn<Professeur, String> EmailColProf;

    @FXML
    private TableColumn<Professeur, String> FillierColProf;

    @FXML
    private TextField txtMatriculeProf;

    @FXML
    private TextField txtNomProf;

    @FXML
    private TextField txtPrenomProf;

    @FXML
    private TextField txtGroupeProf;

    @FXML
    private TextField txtNaissanceProf;

    @FXML
    private TextField txtTelephoneProf;

    @FXML
    private TextField txtAdresseProf;

    @FXML
    private TextField txtEmailProf;

    @FXML
    private TextField txtRechercheProf;
        
    @FXML
    private TableView<Groupe> TabGroupe;

    @FXML
    private TableColumn<Groupe, Integer> MatriculeColGrp;

    @FXML
    private TableColumn<Groupe, String> NomColGrp;

    @FXML
    private TableColumn<Groupe, String> creationColGrp;

    @FXML
    private TableColumn<Groupe, String> NmbrEtuColGrp;

    @FXML
    private TextField txtMatriculeGrp;

    @FXML
    private TextField txtNomGrp;

    @FXML
    private TextField txtDateCreaGrp;

    @FXML
    private TextField txtRechercheProf1;

    @FXML
    private TextField txtNmbrEtuGrp;
    
    @FXML
    private AnchorPane PaneGroupe;

    
    @FXML
    private AnchorPane PaneEtudiant;
      
    @FXML
    private AnchorPane PaneProfesseur;

    
    public void EtudiantPaneShow(){
    
       PaneEtudiant.setVisible(true);
       PaneProfesseur.setVisible(false);
       PaneGroupe.setVisible(false);
    }
    
    public void ProfesseurPaneShow(){
    
        PaneEtudiant.setVisible(false);
        PaneProfesseur.setVisible(true);
        PaneGroupe.setVisible(false);
    }
    
    public void GroupePaneShow(){
    
        PaneEtudiant.setVisible(false);
        PaneProfesseur.setVisible(false);
        PaneGroupe.setVisible(true);
    }

    Connection conn = null ;
    ResultSet rs = null ;
    PreparedStatement pst  = null ;
    String sql = null;
    String etudiant = null;
    String professeur = null;
    String groupe = null;
    
    ObservableList<Etudiant> data ;
    ObservableList<Etudiant> rech ;
    ObservableList<Professeur> dataProf ;
    ObservableList<Groupe> dataGrp ;
    
    int index = -1;
    /*
    Connection conn = null ;
    ResultSet rs = null ;
    PreparedStatement pst  = null ;
    
    */
    
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        data = FXCollections.observableArrayList();
        dataProf = FXCollections.observableArrayList();
        dataGrp = FXCollections.observableArrayList();
        setCellTable();
        getDataEtudiant();
        setCellTableProf();
        getDataProfesseur();
        setCellTableGrp();
        getDataGrp();
    }   
    
     // Ajouter un etudiant
    @FXML
    public void AjoutEtu(){
    
    conn = MysqlConnect.ConnectDb();
    String sql = "INSERT INTO `etudiant`(`Nom`, `Prenom`, `Groupe`, `Date_naissance`, `Telephone`, `Adresse`, `Email`, `Filliere`) VALUES (?,?,?,?,?,?,?,?)";
        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1, txtNom.getText());
            pst.setString(2, txtPrenom.getText());
            pst.setString(3, txtGroupe.getText());
            pst.setString(4, txtNaissance.getText());
            pst.setString(5, txtTelephone.getText());
            pst.setString(6, txtAdresse.getText());
            pst.setString(7, txtEmail.getText());
            pst.setString(8, txtFillier.getText());
            pst.execute();
            
            JOptionPane.showMessageDialog(null, "Ajout reusis");
            ActuListEtu();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
          
    }
    
    
    
    
      // Afficher tous les etudiants 
     @FXML
      private void setCellTable(){
      
        MatriculeCol.setCellValueFactory(new PropertyValueFactory<>("matricule"));
        NomCol.setCellValueFactory(new PropertyValueFactory<>("nom"));
        PrenomCol.setCellValueFactory(new PropertyValueFactory<>("prenom"));
        GroupeCol.setCellValueFactory(new PropertyValueFactory<>("groupe"));
        NaissanceCol.setCellValueFactory(new PropertyValueFactory<>("naissance"));
        TelephoneCol.setCellValueFactory(new PropertyValueFactory<>("telephone"));
        AdresseCol.setCellValueFactory(new PropertyValueFactory<>("adresse"));
        EmailCol.setCellValueFactory(new PropertyValueFactory<>("email"));
        FillierCol.setCellValueFactory(new PropertyValueFactory<>("fillier"));
      }
      
     
      private void getDataEtudiant(){
      
          Connection conn = ConnectDb();
         try {
             pst = conn.prepareStatement("Select * from etudiant");
             rs = pst.executeQuery();
             
             while(rs.next()){
             
                 data.add(new Etudiant(Integer.parseInt(rs.getString(1)), rs.getString(2),rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9)));
             }
         } catch (SQLException ex) {
             Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
         }
         TabEtudiant.setItems(data);
      }
      
      
  
      // Selectionner un etudiants
    @FXML
    void getselectedEtudiant(){
        index = TabEtudiant.getSelectionModel().getSelectedIndex();
        if(index <= -1){
        
            return;
        }
        txtMatricule.setText(MatriculeCol.getCellData(index).toString());
        txtNom.setText(NomCol.getCellData(index).toString());
        txtPrenom.setText(PrenomCol.getCellData(index).toString());
        txtGroupe.setText(GroupeCol.getCellData(index).toString());
        txtNaissance.setText(NaissanceCol.getCellData(index).toString());
        txtTelephone.setText(TelephoneCol.getCellData(index).toString());
        txtAdresse.setText(AdresseCol.getCellData(index).toString());
        txtEmail.setText(EmailCol.getCellData(index).toString());
        txtFillier.setText(FillierCol.getCellData(index).toString());
    }
    
     
    // Modification d'un etudiant
    @FXML
    public void EditEtudiant(){
    
        try {
            conn = MysqlConnect.ConnectDb();
            String value1 = txtMatricule.getText();
            String value2 = txtNom.getText();
            String value3 = txtPrenom.getText();
            String value4 = txtGroupe.getText();
            String value5 = txtNaissance.getText();
            String value6 = txtTelephone.getText();
            String value7 = txtAdresse.getText();
            String value8 = txtEmail.getText();
            String value9 = txtFillier.getText();
            
            
            String sql = "Update etudiant set Matricule ='"+value1+"',Nom ='"+value2+"',"
                    + "Prenom ='"+value3+"',Groupe ='"+value4+"',Date_naissance ='"+value5+"',"
                    + "Telephone ='"+value6+"',Adresse ='"+value7+"',Email ='"+value8+"',"
                    + "Filliere ='"+value9+"' where Matricule = '"+value1+"'";
            pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Modification reussis ");
            ActuListEtu();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        txtMatricule.setText("");
        txtNom.setText("");
        txtPrenom.setText("");
        txtGroupe.setText("");
        txtNaissance.setText("");
        txtTelephone.setText("");
        txtAdresse.setText("");
        txtEmail.setText("");
        txtFillier.setText("");
    }
    
    
    
    // Actualiser la table Etudiant
    @FXML
    public void ActuListEtu(){
         try {
             data.clear();
             sql = "SELECT * FROM etudiant";
             pst = conn.prepareStatement(sql);
             rs = pst.executeQuery();
             
             while(rs.next()){
                 data.add(new Etudiant(rs.getInt("Matricule"), rs.getString("Nom"), rs.getString("Prenom"), rs.getString("Groupe"), rs.getString("Date_naissance"), rs.getString("Telephone"), rs.getString("Adresse"), rs.getString("Email"), rs.getString("Filliere")));
             }
             
         } catch (SQLException ex) {
             Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
         }
    }
    
    
    // Supprimer un etudiants de la table 
    @FXML
    public void DeleteEtudiant(){
        conn = MysqlConnect.ConnectDb();
        try{ 
        String sql = "DELETE FROM `etudiant` WHERE `Matricule` = ?";
            pst = conn.prepareStatement(sql);
            pst.setString(1, txtMatricule.getText());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Suppression reussis ");
            ActuListEtu();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        txtMatricule.setText("");
        txtNom.setText("");
        txtPrenom.setText("");
        txtGroupe.setText("");
        txtNaissance.setText("");
        txtTelephone.setText("");
        txtAdresse.setText("");
        txtEmail.setText("");
        txtFillier.setText("");
    }
    
    
    
    @FXML
    public void rechercheEtudiant(){
    
       MatriculeCol.setCellValueFactory(new PropertyValueFactory<Etudiant, Integer>("id"));
       NomCol.setCellValueFactory(new PropertyValueFactory<Etudiant, String>("nom"));
       PrenomCol.setCellValueFactory(new PropertyValueFactory<Etudiant, String>("prenom"));
       GroupeCol.setCellValueFactory(new PropertyValueFactory<Etudiant, String>("groupe"));
       NaissanceCol.setCellValueFactory(new PropertyValueFactory<Etudiant, String>("naissance"));
       TelephoneCol.setCellValueFactory(new PropertyValueFactory<Etudiant, String>("telephone"));
       AdresseCol.setCellValueFactory(new PropertyValueFactory<Etudiant, String>("adresse"));
       EmailCol.setCellValueFactory(new PropertyValueFactory<Etudiant, String>("Email"));
       FillierCol.setCellValueFactory(new PropertyValueFactory<Etudiant, String>("filliere"));
       
       conn = MysqlConnect.ConnectDb();
       TabEtudiant.setItems(rech);
        FilteredList<Etudiant> filteredData = new FilteredList<>(rech, b -> true);
        txtMatricule.textProperty().addListener(((observable, oldValue, newValue) -> {
            filteredData.setPredicate(personne -> {
                   if(newValue == null || newValue.isEmpty()){
                   return true;
                   }
                   String lowerCaseFilter = newValue.toLowerCase();
                   //filtrer le nom
                   if(personne.getNom().toLowerCase().indexOf(lowerCaseFilter) != -1 ){return true;}
                   //filtrer le prenom
                   else if(personne.getPrenom().toLowerCase().indexOf(lowerCaseFilter) != -1 ){return true;}
                   //filtrer le groupe
                   else if(personne.getGroupe().toLowerCase().indexOf(lowerCaseFilter) != -1 ){return true;}
                   //filtrer le naissance
                   else if(personne.getNaissance().toLowerCase().indexOf(lowerCaseFilter) != -1 ){return true;}
                   //filtrer le telephone
                   else if(personne.getTelephone().toLowerCase().indexOf(lowerCaseFilter) != -1 ){return true;}
                   //filtrer le Adresse
                   else if(personne.getAdresse().toLowerCase().indexOf(lowerCaseFilter) != -1 ){return true;}
                   //filtrer l'Email
                   else if(String.valueOf(personne.getEmail()).toLowerCase().indexOf(lowerCaseFilter) != -1 ){return true;}
                   //filtrer le filiere
                   else if(personne.getFillier().toLowerCase().indexOf(lowerCaseFilter) != -1 ){return true;}
                   
                   // Quand sa marche pas
                return false;
            
            });
        }));
        SortedList<Etudiant> sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(TabEtudiant.comparatorProperty());
        TabEtudiant.setItems(sortedData);
    }
    
    // Ajouter un professeur
    @FXML
    public void AjoutProf(){
    
    conn = MysqlConnect.ConnectDb();
    String sql = "INSERT INTO `professeur`(`Nom`, `Prenom`, `Groupe`, `Telephone`, `Adresse`, `DateNaissance`, `Email`) VALUES (?,?,?,?,?,?,?)";
        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1, txtNomProf.getText());
            pst.setString(2, txtPrenomProf.getText());
            pst.setString(3, txtGroupeProf.getText());
            pst.setString(4, txtTelephoneProf.getText());
            pst.setString(5, txtAdresseProf.getText());
            pst.setString(6, txtNaissanceProf.getText());
            pst.setString(7, txtEmailProf.getText());
            pst.execute();
            
            JOptionPane.showMessageDialog(null, "Ajout reusis");
            ActuListProf();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
          
    }
    
      // Afficher tous les Prof 
     @FXML
      private void setCellTableProf(){
      
        MatriculeColProf.setCellValueFactory(new PropertyValueFactory<>("matriculeProf"));
        NomColProf.setCellValueFactory(new PropertyValueFactory<>("nomProf"));
        PrenomColProf.setCellValueFactory(new PropertyValueFactory<>("prenomProf"));
        GroupeColProf.setCellValueFactory(new PropertyValueFactory<>("groupeProf"));
        NaissanceColProf.setCellValueFactory(new PropertyValueFactory<>("naissanceProf"));
        TelephoneColProf.setCellValueFactory(new PropertyValueFactory<>("telephoneProf"));
        AdresseColProf.setCellValueFactory(new PropertyValueFactory<>("adresseProf"));
        EmailColProf.setCellValueFactory(new PropertyValueFactory<>("emailProf"));
        
      }
     
      private void getDataProfesseur(){
      
          Connection conn = ConnectDb();
         try {
             pst = conn.prepareStatement("Select * from professeur");
             rs = pst.executeQuery();
             
             while(rs.next()){
             
                 dataProf.add(new Professeur(Integer.parseInt(rs.getString(1)),rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8)));
             }
         } catch (SQLException ex) {
             Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
         }
         TabProfesseur.setItems(dataProf);
      }
      
      // Selectionner un Prof
    @FXML
    void getselectedProf(){
        index = TabProfesseur.getSelectionModel().getSelectedIndex();
        if(index <= -1){
        
            return;
        }
        txtMatriculeProf.setText(MatriculeColProf.getCellData(index).toString());
        txtNomProf.setText(NomColProf.getCellData(index).toString());
        txtPrenomProf.setText(PrenomColProf.getCellData(index).toString());
        txtGroupeProf.setText(GroupeColProf.getCellData(index).toString());
        txtNaissanceProf.setText(NaissanceColProf.getCellData(index).toString());
        txtTelephoneProf.setText(TelephoneColProf.getCellData(index).toString());
        txtAdresseProf.setText(AdresseColProf.getCellData(index).toString());
        txtEmailProf.setText(EmailColProf.getCellData(index).toString());
    }
    
    // Modification d'un Prof
    @FXML
    public void EditProf(){
    
        try {
            conn = MysqlConnect.ConnectDb();
            String value1 = txtMatriculeProf.getText();
            String value2 = txtNomProf.getText();
            String value3 = txtPrenomProf.getText();
            String value4 = txtGroupeProf.getText();
            String value5 = txtTelephoneProf.getText();
            String value6 = txtAdresseProf.getText();
            String value7 = txtNaissanceProf.getText();
            String value8 = txtEmailProf.getText();
            
            
            String sql = "UPDATE `professeur` SET `Matricule`= '"+value1+"',`Nom`='"+value2+"',"
                    + "`Prenom`='"+value3+"',`Groupe`='"+value4+"',`Telephone`='"+value5+"',"
                    + "`Adresse`='"+value6+"',`DateNaissance`='"+value7+"',`Email`='"+value8    +"' WHERE `Matricule` = '"+value1+"'";
            
            pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Modification reussis ");
            ActuListProf();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        txtMatricule.setText("");
        txtNom.setText("");
        txtPrenom.setText("");
        txtGroupe.setText("");
        txtNaissance.setText("");
        txtTelephone.setText("");
        txtAdresse.setText("");
        txtEmail.setText("");
    }
    
    // Actualiser la table Professeur
    @FXML
    public void ActuListProf(){
         try {
             dataProf.clear();
             sql = "SELECT * FROM professeur";
             pst = conn.prepareStatement(sql);
             rs = pst.executeQuery();
             
             while(rs.next()){
                 dataProf.add(new Professeur(rs.getInt("Matricule"), rs.getString("Nom"), rs.getString("Prenom"), rs.getString("Groupe"), rs.getString("Telephone"), rs.getString("Adresse"), rs.getString("DateNaissance"), rs.getString("Email")));
             }
             
         } catch (SQLException ex) {
             Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
         }
    }
    // Supprimer un Prof de la table 
    @FXML
    public void DeleteProf(){
        conn = MysqlConnect.ConnectDb();
        try{ 
        String sql = "DELETE FROM `professeur` WHERE `Matricule` = ?";
            pst = conn.prepareStatement(sql);
            pst.setString(1, txtMatriculeProf.getText());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Suppression reussis ");
            ActuListProf();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        txtMatricule.setText("");
        txtNom.setText("");
        txtPrenom.setText("");
        txtGroupe.setText("");
        txtNaissance.setText("");
        txtTelephone.setText("");
        txtAdresse.setText("");
        txtEmail.setText("");
        txtFillier.setText("");
    }
    
    // Ajouter un Groupe
    @FXML
    public void AjoutGrp(){
    
    conn = MysqlConnect.ConnectDb();
    String sql = "INSERT INTO `groupe`( `NomGroupe`, `DateCreation`, `NmbrEtu`) VALUES (?,?,?)";
        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1, txtNomGrp.getText());
            pst.setString(2, txtDateCreaGrp.getText());
            pst.setString(3, txtNmbrEtuGrp.getText());
            pst.execute();
            
            JOptionPane.showMessageDialog(null, "Ajout reusis");
            ActuListProf();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
          
    }
    
      // Afficher tous les Groupe 
     @FXML
      private void setCellTableGrp(){
      
        MatriculeColGrp.setCellValueFactory(new PropertyValueFactory<>("matriculeGrp"));
        NomColGrp.setCellValueFactory(new PropertyValueFactory<>("nomGrp"));
        creationColGrp.setCellValueFactory(new PropertyValueFactory<>("dateCreation"));
        NmbrEtuColGrp.setCellValueFactory(new PropertyValueFactory<>("nmbrEtu"));
        
        
      }
     
      private void getDataGrp(){
      
          Connection conn = ConnectDb();
         try {
             pst = conn.prepareStatement("Select * from groupe");
             rs = pst.executeQuery();
             
             while(rs.next()){
             
                 dataGrp.add(new Groupe(Integer.parseInt(rs.getString(1)),rs.getString(2), rs.getString(3), rs.getString(4)));
             }
         } catch (SQLException ex) {
             Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
         }
         TabGroupe.setItems(dataGrp);
      }
      
      // Selectionner un groupe
    @FXML
    void getselectedGrp(){
        index = TabGroupe.getSelectionModel().getSelectedIndex();
        if(index <= -1){
        
            return;
        }
        txtMatriculeGrp.setText(MatriculeColGrp.getCellData(index).toString());
        txtNomGrp.setText(NomColGrp.getCellData(index).toString());
        txtDateCreaGrp.setText(creationColGrp.getCellData(index).toString());
        txtGroupeProf.setText(NmbrEtuColGrp.getCellData(index).toString());
    }
    
    // Modification d'un Prof
    @FXML
    public void EditGrp(){
    
        try {
            conn = MysqlConnect.ConnectDb();
            String value1 = txtMatriculeGrp.getText();
            String value2 = txtNomGrp.getText();
            String value3 = txtDateCreaGrp.getText();
            String value4 = txtNmbrEtuGrp.getText();
            
            String sql = "UPDATE `groupe` SET `Matricule`='"+value1+"',`NomGroupe`='"+value2+"',`DateCreation`='"+value3+"',`NmbrEtu`='"+value4+"' WHERE `Matricule` = '"+value1+"'";
            
            pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Modification reussis ");
            ActuListProf();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        txtMatricule.setText("");
        txtNomGrp.setText("");
        txtDateCreaGrp.setText("");
        txtNmbrEtuGrp.setText("");
    }
    
    // Actualiser la table Professeur
    @FXML
    public void ActuListGrp(){
         try {
             dataGrp.clear();
             sql = "SELECT * FROM groupe";
             pst = conn.prepareStatement(sql);
             rs = pst.executeQuery();
             
             while(rs.next()){
                 dataGrp.add(new Groupe(rs.getInt("Matricule"), rs.getString("NomGroupe"), rs.getString("DateCreation"), rs.getString("NmbrEtu")));
             }
             
         } catch (SQLException ex) {
             Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
         }
    }
    // Supprimer un Groupe de la table 
    @FXML
    public void DeleteGrp(){
        conn = MysqlConnect.ConnectDb();
        try{ 
        String sql = "DELETE FROM `groupe` WHERE `Matricule` = ?";
            pst = conn.prepareStatement(sql);
            pst.setString(1, txtMatriculeGrp.getText());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Suppression reussis ");
            ActuListGrp();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        txtMatriculeGrp.setText("");
        txtNomGrp.setText("");
        txtDateCreaGrp.setText("");
        txtNmbrEtuGrp.setText("");
    }
}
